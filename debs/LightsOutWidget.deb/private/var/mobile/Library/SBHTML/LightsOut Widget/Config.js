var twentyfourhour = false; 
var pad = true; 
